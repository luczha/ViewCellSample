﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;

using MyApp;
using MyApp.iOS;

using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomVeggieCell), typeof(ViewCellItemSelectedCustomRenderer))]
namespace MyApp.iOS
{
    public class ViewCellItemSelectedCustomRenderer : ViewCellRenderer
    {
        private UIView bgView;


        public ViewCellItemSelectedCustomRenderer()
        {

        }


        

        public override UITableViewCell GetCell(Cell item, UITableViewCell reusableCell, UITableView tv)
        {
            UITableViewCell viewCell = base.GetCell(item, reusableCell, tv);
            if (viewCell != null)
            {
                if (bgView == null)
                {
                    bgView = new UIView(viewCell.SelectedBackgroundView.Bounds);
                    bgView.Layer.BackgroundColor = Color.FromHex("#666495").ToCGColor();
                    bgView.Layer.MasksToBounds = true;
                    bgView.Layer.CornerRadius = new nfloat(17.5);
                }

                viewCell.SelectedBackgroundView = bgView;
            }
            return viewCell;
        }
    }
}