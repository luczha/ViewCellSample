﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp
{
    public class VeggieViewModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Image { get; set; }
    }
}
