﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
namespace MyApp
{
    public class MyListView:ListView
    {
        public MyListView()
        {

        }
    }
}
